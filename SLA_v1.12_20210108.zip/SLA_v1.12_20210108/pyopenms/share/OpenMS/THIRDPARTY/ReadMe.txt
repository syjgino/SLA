This folder contains the third-party tools bundled in the installers.
It will be empty after cloning the repository and will only be filled by our packaging scripts.
